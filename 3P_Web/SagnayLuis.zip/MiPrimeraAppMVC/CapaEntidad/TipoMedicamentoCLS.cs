﻿namespace CapaEntidad
{
    public class TipoMedicamentoCLS
    {
        public int idTipoMedicamento { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public int stock { get; set; }
    }
}
