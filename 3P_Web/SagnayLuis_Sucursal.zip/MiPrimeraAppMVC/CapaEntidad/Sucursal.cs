﻿
namespace CapaEntidad
{
    public class Sucursal
    {
        public int iidSucursal { get; set; }
        public string nombre { get; set; }
        public string direccion { get; set; }
    }
}
