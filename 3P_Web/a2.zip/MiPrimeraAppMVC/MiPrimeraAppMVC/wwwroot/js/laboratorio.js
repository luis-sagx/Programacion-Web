﻿window.onload = function () {
    listarLaboratorios();
};

function filtrarLaboratorios() {
    let nombre = get("txtLaboratorio");
    if (nombre == "") {
        listarLaboratorios();
    } else {
        objLaboratorio.url = "Laboratorio/filtrarLaboratorios/?nombre=" + nombre;
        pintar(objLaboratorio);
    }

}

let objLaboratorio;

async function listarLaboratorios() {
    objLaboratorio = {
        url: "Laboratorio/listarLaboratorios",
        cabeceras: ["id Laboratorio", "Nombre", "Direccion", "Persona Contacto"],
        propiedades: ["iidLaboratorio", "nombre", "direccion", "personaContacto"]
    }

    pintar(objLaboratorio);

}
