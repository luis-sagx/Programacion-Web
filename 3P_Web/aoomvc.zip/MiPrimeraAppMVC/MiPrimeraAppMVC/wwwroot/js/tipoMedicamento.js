﻿window.onload = function () {
    listarTipoMedicamento();
};

let objTipoMedicamento;

async function listarTipoMedicamento() {
    objTipoMedicamento = {
        url: "tipoMedicamento/listarTipoMedicamento",
        cabeceras: ["id Tipo Medicamento", "Nombre", "Descripcion"],
        propiedades: ["idTipoMedicamento", "nombre", "descripcion"]
    }

    pintar(objTipoMedicamento);

}

function Buscar() {
    let nombreTipoMedicamento = document.getElementById("txtTipoMedicamento").value;
    objTipoMedicamento.url = "tipoMedicamento/filtrarTipoMedicamento/?nombre=" + nombreTipoMedicamento;
    pintar(objTipoMedicamento);
}
function Limpiar() {
    listarTipoMedicamento();
    document.getElementById("txtTipoMedicamento").value = "";
}
