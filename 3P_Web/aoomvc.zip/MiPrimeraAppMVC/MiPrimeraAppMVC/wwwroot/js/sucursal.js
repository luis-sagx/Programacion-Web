﻿window.onload = function () {
    listarSucursales();
};

let objSucursales;

async function listarSucursales() {
    objSucursales = {
        url: "Sucursal/listarSucursales",
        cabeceras: ["id Sucursal", "Nombre", "Direccion"],
        propiedades: ["iidSucursal", "nombre", "direccion"]
    }
    pintar(objSucursales);
}

function Buscar() {
    let nombreSucursal = document.getElementById("txtSucursales").value;
    objSucursales.url = "Sucursal/filtrarSucursales/?nombre=" + nombreSucursal; 
    pintar(objSucursales); 
}

function Limpiar() {
    listarSucursales(); 
    document.getElementById("txtSucursales").value = "";
}
