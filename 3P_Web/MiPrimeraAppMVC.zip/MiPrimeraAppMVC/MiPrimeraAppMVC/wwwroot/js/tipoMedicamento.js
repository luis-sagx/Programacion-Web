﻿window.onload = function () {
    listarTipoMedicamento();
};

async function listarTipoMedicamento() {
    pintar({
        url: "tipoMedicamento/listarTipoMedicamento",
        cabeceras: ["id Tipo Medicamento", "Nombre", "Descripcion"],
        propiedades: ["idTipoMedicamento", "nombre", "descripcion"]
    })

    //fetchGet("tipoMedicamento/listarTipoMedicamento", "json", function (res) {
    //    let nroRegistros = res.length;
    //    let contenido = "";

    //    contenido += "<table class='table'>";
    //    contenido += "<thead>";
    //    contenido += "<tr>";
    //    contenido += "<th>Id Tipo Medicamento</th>";
    //    contenido += "<th>Nombre</th>";
    //    contenido += "<th>Descripción</th>";
    //    contenido += "</tr>";
    //    contenido += "</thead>";

    //    let obj;
    //    contenido += "<tbody>";

    //    for (let i = 0; i < nroRegistros; i++) {
    //        obj = res[i];
    //        contenido += "<tr>";
    //        contenido += `<td>${obj.idTipoMedicamento}</td>`;
    //        contenido += `<td>${obj.nombre}</td>`;
    //        contenido += `<td>${obj.descripcion}</td>`;
    //        contenido += "</tr>";
    //    }

    //    contenido += "</tbody>";
    //    contenido += "</table>";

    //    document.getElementById("divTable").innerHTML = contenido;
    //});
}
